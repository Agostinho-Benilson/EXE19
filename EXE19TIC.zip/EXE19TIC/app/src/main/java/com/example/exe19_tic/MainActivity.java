package com.example.exe19_tic;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private EditText txt_horas;
    private Button btn_calcular;
    private TextView resultado;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txt_horas = findViewById(R.id.txt_horas);
        btn_calcular = findViewById(R.id.btn_calcular);
        resultado = findViewById(R.id.resultado);

        btn_calcular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int horas = Integer.parseInt(txt_horas.getText().toString());
                int  Dias = (horas % (24 * 7))/ 24;
                int semana = horas / 168;
                int horas2 = horas / 24;

                resultado.setText(horas + "h " + "são " + semana+ " semana, " + Dias + " Dias e " + horas2 + " horas" );


            }
        });
    }
}